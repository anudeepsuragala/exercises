package com.example.lazy;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;

public class frndsactivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frndsactivity);

        Button button1 = findViewById(R.id.anudeep);
        Button button2 = findViewById(R.id.sushma);
        Button button3 = findViewById(R.id.haripriya);
        Button button4 = findViewById(R.id.anil);
        Button button5 = findViewById(R.id.renuka);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), homeactivity.class);
                startActivity(intent);

            }

        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), sushmaactivity.class);
                startActivity(intent);

            }

        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),haripriyaactivity.class);
                startActivity(intent);

            }

        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),anilactivity.class);
                startActivity(intent);

            }

        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), renuactivity.class);
                startActivity(intent);

            }

        });
    }
}
