package com.example.myretrofit;



import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class Results<R> {
    @SerializedName("rawData")
    @Expose
    private List<RawDatum> rawData = null;
    public List<RawDatum> getRawData() {
        return rawData;
    }
    public void setRawData(List<RawDatum> rawData) {
        this.rawData = rawData;
    }
}