package com.example.myretrofit;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        gettingData();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
    }
    private void gettingData() {
        Api apiInterface =RetrofitClient.getRetrofit().create(Api.class);
        Call<Results<RawDatum>> listingData= apiInterface.getCountryRegion();
        listingData.enqueue(new Callback<Results<RawDatum>>() {
            @Override
            public void onResponse(Call<Results<RawDatum>> call, Response<Results<RawDatum>> response) {
                if (response.isSuccessful()){
                    RecyclerAdapter recyclerAdapter = new RecyclerAdapter(response.body().getRawData());
                    recyclerView.setAdapter(recyclerAdapter);
                }
            }
            @Override
            public void onFailure(Call<Results<RawDatum>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }




    class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder>{
        List<RawDatum> list;
        public RecyclerAdapter(List<RawDatum> list) {
            this.list = list;
        }
        @NonNull
        @Override
        public RecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, null);
            RecyclerAdapter.MyViewHolder viewHolder = new RecyclerAdapter.MyViewHolder(v);
            return viewHolder;
        }
        @Override
        public void onBindViewHolder(@NonNull RecyclerAdapter.MyViewHolder holder, int position) {
            holder.CountryRegion.setText(list.get(position).getCountryRegion());
            holder.Confirmed.setText(list.get(position).getConfirmed());
            holder.Deaths.setText(list.get(position).getDeaths());
        }
        @Override
        public int getItemCount() {
            return list.size();
        }
        class MyViewHolder extends RecyclerView.ViewHolder{
            private   TextView CountryRegion, Confirmed, Deaths;
            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                CountryRegion=itemView.findViewById(R.id.tv1);
                Confirmed = itemView.findViewById(R.id.tv2);
                Deaths = itemView.findViewById(R.id.tv3);
            }
        }
    }
}


