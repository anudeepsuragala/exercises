package com.example.myretrofit;

import retrofit2.Call;
import retrofit2.http.GET;
public interface Api {
      String BASE_URL = "https://coronavirus.m.pipedream.net/";

      @GET(".")
      Call<Results<RawDatum>> getCountryRegion();
}




