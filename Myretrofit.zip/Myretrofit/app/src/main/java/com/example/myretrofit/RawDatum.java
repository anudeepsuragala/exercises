package com.example.myretrofit;




import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class RawDatum {
    @SerializedName("Country_Region")
    @Expose
    private String countryRegion;
    @SerializedName("Confirmed")
    @Expose
    private String confirmed;
    @SerializedName("Deaths")
    @Expose
    private String deaths;
    public String getCountryRegion() {
        return countryRegion;
    }
    public void setCountryRegion(String countryRegion) {
        this.countryRegion = countryRegion;
    }
    public String getConfirmed() {
        return confirmed;
    }
    public void setConfirmed(String confirmed) {
        this.confirmed = confirmed;
    }
    public String getDeaths() {
        return deaths;
    }
    public void setDeaths(String deaths) {
        this.deaths = deaths;
    }
}


