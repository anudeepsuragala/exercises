package com.example.iprism;

public class fastfoods {
}
