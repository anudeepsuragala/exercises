package com.example.iprism;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class dairypro {
    private Button fruitsBtn, dairypoductsBtn, fastfoodsaBtn, homeneedsBtn;

    }
