package com.example.iprism;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button button2;
    View view;
    private View fruitsBtn;
    private View dairypoductsBtn;
    private View fastfoodsaBtn;
    private View homeneedsBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        fruitsBtn = fruitsBtn.findViewById();
         dairypoductsBtn = dairypoductsBtn.findViewById();
        fastfoodsaBtn = fastfoodsaBtn.findViewById();
        homeneedsBtn = homeneedsBtn.findViewById();

        fruitsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                replaceFragment(new fruits());

            }
        });

        dairypoductsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                replaceFragment(new dairypro());

            }
        });
        fruitsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                replaceFragment(new fastfoods());

            }
        });
        fruitsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                replaceFragment(new homeneeds());

            }

            private void replaceFragment(homeneeds homeneeds) {
            }
        });




    }

    private void replaceFragment(fruits fruits) {
    }

    private void setContentView(int activity_main) {
    }

    private void replaceFragment(dairypro fragment) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        fragmentTransaction.commit();

    }












}