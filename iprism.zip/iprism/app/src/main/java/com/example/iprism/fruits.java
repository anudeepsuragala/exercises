package com.example.iprism;

import android.content.Intent;
import android.view.View;
import android.widget.Button;


public class fruits<button2> extends fastfoods {

        button2  = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View Object view;
        view) {
            openDairy();
        }
    });
}
    public void openDairy(){
        Intent intent = new Intent(this,dairypro.class);
        startActivity(intent);
    }

    private void startActivity(Intent intent) {
    }
}
