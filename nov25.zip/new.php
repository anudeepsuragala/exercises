<?<php
$username =$_POST['username'];
$password =$_POST['password'];
//databaseconnection 
$con = newmysqli("localhost","root","","anudeepdb")
if($con->connect_error)
{
    die("failed to connect : ".$con->connect_error);
}else{
    $stmt = $con->prepare("select * from registration where email=?");
    $stmt->bind_param("s",$username);
    $stmt->execute();
    $stmt_result = $stmt->get_result();
    if($stmt_result->numrows> 0){
    $data =$stmt_result->fetch_assoc();
    if($data['password'] === $password){
        echo"<h2>login successfully</h2>";
    }else{
        echo"<h2>invalid user or password</h2>
    }

}
else{
    echo"<h2>invalid user or password</h2>";
}
    }
/php>