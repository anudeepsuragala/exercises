package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView username =(TextView) findViewById(R.id.username);
        TextView password =(TextView) findViewById(R.id.password);

        Button loginbtn = (Button) findViewById(R.id.button_id);
        Button resetbtn = (Button) findViewById(R.id.button_id1);

        loginbtn.setOnClickListener (new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (username.getText().toString().equals("user") &&
                        password.getText().toString().equals("pass")) {

                }
                resetbtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            username.setText("");
                            password.setText("");
                    Toast.makeText(MainActivity.this,
                            "RESULT: Logged in successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), homeactiviy.class);
                    startActivity(intent);
                }
        });
        }
    });
    }
}








